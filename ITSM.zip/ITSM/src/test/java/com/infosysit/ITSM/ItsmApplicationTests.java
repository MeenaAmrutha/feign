package com.infosysit.ITSM;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItsmApplicationTests {

	@Test
	void contextLoads() {
	}

}
