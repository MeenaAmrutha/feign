package com.infosysit.ITSM.mysqlDataSource.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.infosysit.ITSM.model.ISLeap_Ticket;
import com.infosysit.ITSM.mysqlDataSource.entity.ICM_Tickets;
import com.infosysit.ITSM.util.QueryConstants;

public interface ICM_TicketsRepository extends JpaRepository<ICM_Tickets, Integer> {
	
	@Query(value=QueryConstants.GETICMOPENTICKETSDETAILS)
	List<ISLeap_Ticket> GetIcmOpenTickets();
	
	@Transactional
	@Modifying
	@Query(value=QueryConstants.UPDATEICMTICKETSUSINGNUMBER)
	void UpdateIcmTicketsUsingNumber(@Param("number") String number,@Param("resolutionSteps") String resolutionSteps);
	
	@Transactional
	@Modifying
	@Query(value=QueryConstants.UPDATEICMTICKETSNOTREQUIRED)
	void UpdateIcmTicketsNotRequired(@Param("number") String number,@Param("resolutionSteps") String resolutionSteps,@Param("subCategory") String subCategory);
	
	@Transactional
	@Modifying
	@Query(value=QueryConstants.UPDATEICMTICKETSREQUIRED)
	void UpdateIcmTicketsRequired(@Param("number") String number,@Param("resolutionSteps") String resolutionSteps,@Param("subCategory") String subCategory);
	
	@Query(value=QueryConstants.GETICMOPENTICKETSNUMBERS)
	List<String> GetIcmOpenTicketNumbers();
	

}