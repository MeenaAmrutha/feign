package com.infosysit.ITSM.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class EDSTrnDepPassportDetailsModel {
	public String txtEmpNo;
	public Integer intSerialNo;
	public String txtNameInPassPort;
	public String txtPassPortNo;

	public EDSTrnDepPassportDetailsModel(String txtEmpNo,Integer intSerialNo,String txtNameInPassPort,String txtPassPortNo) {
		super();
		this.txtEmpNo=txtEmpNo == null ? "" : String.valueOf(txtEmpNo);
		this.intSerialNo=intSerialNo;
		this.txtNameInPassPort = txtNameInPassPort == null ? "" : String.valueOf(txtNameInPassPort);
		this.txtPassPortNo = txtPassPortNo == null ? "" : String.valueOf(txtPassPortNo);
		
	}
}
