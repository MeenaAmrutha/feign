package com.infosysit.ITSM.util;

public class QueryConstants {
	public static final String GETICMOPENTICKETSDETAILS="select new com.infosysit.ITSM.model.ISLeap_Ticket(caller,number,shortdescription,category,createdDate,sysId,madesla) from ICM_Tickets where projectId=114 and state='Open' and sop='Travel missing dependent details'";
	
	public static final String GETDEPENDENTPASSPORTDETAILS="select new com.infosysit.ITSM.model.EDSTrnDepPassportDetailsModel(txtEmpNo,intSerialNo,txtNameInPassPort,txtPassPortNo) from EDSTrnDepPassportDetails  where txtEmpNo=:txtEmpNo";

	public static final String UPDATEICMTICKETSUSINGNUMBER="update ICM_Tickets set resolutionSteps=:resolutionSteps,state='Resolved' where number=:number";
	
	public static final String GETICMOPENTICKETSNUMBERS="select number from ICM_Tickets where projectId=114 and sop='Auto closure response transfer' and state='Open'";

	public static final String GETRULEUSINGTICKETNUMBER="select intRuleNo from ISLeapTrnRuleMapping where txtAhdTicket=:txtAhdTicket";

	public static final String GETRESOLUTIONDETAILS="select  new com.infosysit.ITSM.model.ISLeap_AutoResponseModel(txtStatusCode,txtSuggestion,txtTransfer,txtNewCategoryName,txtNewDeptName) from ISLeapMstAutoResponse where intRuleNo=:intRuleNo";

	public static final String UPDATEICMTICKETSNOTREQUIRED="update ICM_Tickets set state='Acknowledged',resolutionSteps=:resolutionSteps,subcategory=:subCategory where number=:number";

	public static final String UPDATEICMTICKETSREQUIRED="update ICM_Tickets set state='Transfer_Required',resolutionSteps=:resolutionSteps,subcategory=:subCategory where number=:number";

}
