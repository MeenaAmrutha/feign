package com.infosysit.ITSM.util;


public class AuthenticationClass {
	public static String GetUserMailFromLoginId(String loginId)
    {
        String MailId = "";
        if (loginId.isEmpty() || loginId.equals(null))
        {
            MailId = "";
        }
        else if (loginId.toUpperCase().startsWith(InfraConstants.INFOSYSDOMAINPREFIXITL))
        {
            MailId = loginId.toUpperCase().replace(InfraConstants.INFOSYSDOMAINPREFIXITL, "");
        }
        else if (loginId.toUpperCase().endsWith(InfraConstants.INFOSYSDOMAINSUFFIX))
        {
            MailId = loginId.toUpperCase().replace(InfraConstants.INFOSYSDOMAINSUFFIX, "");
        }
        else if (loginId.toUpperCase().endsWith(InfraConstants.INFOSYSDOMAINSUFFIXAD))
        {
            MailId = loginId.toUpperCase().replace(InfraConstants.INFOSYSDOMAINSUFFIXAD, "");
        }
        return MailId;
    }
}
