package com.infosysit.ITSM.mysqlDataSource.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.infosysit.ITSM.model.ISLeap_AutoResponseModel;
import com.infosysit.ITSM.mysqlDataSource.entity.ISLeapMstAutoResponse;
import com.infosysit.ITSM.util.QueryConstants;

public interface ISLeapMstAutoResponseRepository extends JpaRepository<ISLeapMstAutoResponse, Integer> {
	
	@Query(value=QueryConstants.GETRESOLUTIONDETAILS)
	ISLeap_AutoResponseModel GetResolutionDetails(@Param("intRuleNo") int intRuleNo);
	

}