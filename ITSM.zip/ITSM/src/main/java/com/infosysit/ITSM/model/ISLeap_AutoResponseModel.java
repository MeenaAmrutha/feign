package com.infosysit.ITSM.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ISLeap_AutoResponseModel {
	public String status;
	public String suggestion;
	public String transfer;
	public String newCategoryName;
	public String deptName;
	public ISLeap_AutoResponseModel(String status, String suggestion, String transfer, String newCategoryName,
			String deptName) {
		super();
		this.status=status == null ? "" : String.valueOf(status);
		this.suggestion=suggestion == null ? "" : String.valueOf(suggestion);
		this.transfer = transfer == null ? "" : String.valueOf(transfer);
		this.newCategoryName = newCategoryName == null ? "" : String.valueOf(newCategoryName);
		this.deptName = deptName == null ? "" : String.valueOf(deptName);
	}
}
