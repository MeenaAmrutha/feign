package com.infosysit.ITSM.mysqlDataSource.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="ISLeapMstAutoResponse")
@NoArgsConstructor
public class ISLeapMstAutoResponse {
	@Id
	@Column(name="intPKID")
	private int intPKID;
	
	@Column(name="intCategoryId")
	private int intCategoryId;
	
	@Column(name="txtCategoryName")
	private String txtCategoryName;
	
	@Column(name="txtKeyword")
	private String txtKeyword;
	
	@Column(name="txtSuggestion")
	private String txtSuggestion;
	
	@Column(name="txtStatusCode")
	private String txtStatusCode;
	
	@Column(name="txtTransfer")
	private String txtTransfer;
	
	@Column(name="numNewDeptID")
	private int numNewDeptID;
	
	@Column(name="txtNewDeptName")
	private String txtNewDeptName;
	
	@Column(name="intNewCategoryId")
	private int intNewCategoryId;
	
	@Column(name="txtNewCategoryName")
	private String txtNewCategoryName;
	
	@Column(name="intRuleNo")
	private int intRuleNo;
	
	public ISLeapMstAutoResponse(String txtStatusCode, String txtSuggestion, String txtTransfer, String txtNewCategoryName,
			String txtNewDeptName) {
		super();
		this.txtStatusCode=txtStatusCode;
		this.txtSuggestion=txtSuggestion;
		this.txtTransfer = txtTransfer;
		this.txtNewCategoryName = txtNewCategoryName;
		this.txtNewDeptName = txtNewDeptName;
		//this.dtModifiedOn = dtModifiedOn;
	}
}