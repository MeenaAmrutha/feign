package com.infosysit.ITSM.telemetry;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.sunbird.common.models.util.JsonKey;
import org.sunbird.common.request.Request;
import org.sunbird.telemetry.util.TelemetryEvents;
import org.sunbird.telemetry.util.TelemetryLmaxWriter;

import com.infosysit.ITSM.telemetry.Event;

@Component
@SuppressWarnings("unchecked")
public class AuditEvent extends Event {

	private TelemetryLmaxWriter lmaxWriter = TelemetryLmaxWriter.getInstance();

	public void setTelemetryData( String message) {

		super.initializeRequestInfo();
		setEventData(message);

	}

	public void setEventData(String message) {

		// Send Telemetry events

		Map<String, Object> telemetryInfo = requestInfo.get(Event.messageId);

		Request telemetryRequest = new Request();

		// targetObject and correlatedObjects are required maps which needs to be set

		// targetObject is a map where we have to set currentstate , id and type
		Map<String, Object> targetObject = new HashMap<>();

		// not setting anything in correlatedObjects
		Map<String, Object> correlatedObjects = new HashMap<>();

		targetObject.put(JsonKey.CURRENT_STATE, message);
		targetObject.put(JsonKey.ID, "Audit");
		targetObject.put(JsonKey.TYPE, "Audit Content");

		// params is a required map where we set targetObject,CorrelatedObject and
		// props(required field for AuditEvent)
		Map<String, Object> params = new HashMap<>();
		params.put(JsonKey.TARGET_OBJECT, targetObject);
		params.put(JsonKey.CORRELATED_OBJECTS, correlatedObjects);
		Map<String, Object> props = new HashMap<>();
		params.put(JsonKey.PROPS, props);
		List<Map<String, Object>> list = new ArrayList<>();
		params.put(JsonKey.CORRELATED_OBJECTS, list);

		// creating telemetry request
		telemetryRequest.setRequest(generateTelemetryRequest(TelemetryEvents.AUDIT.getName(), params,
				(Map<String, Object>) telemetryInfo.get(JsonKey.CONTEXT), targetObject, list));

		lmaxWriter.submitMessage(telemetryRequest);
	}

	private Map<String, Object> generateTelemetryRequest(String eventType, Map<String, Object> params,
			Map<String, Object> telemetryContext, Map<String, Object> targetObject,
			List<Map<String, Object>> correlatedObjects) {
		Map<String, Object> map = new HashMap<>();
		map.put(JsonKey.TELEMETRY_EVENT_TYPE, eventType);
		map.put(JsonKey.CONTEXT, telemetryContext);
		map.put(JsonKey.PARAMS, params);
		map.put(JsonKey.TARGET_OBJECT, targetObject);
		map.put(JsonKey.CORRELATED_OBJECTS, correlatedObjects);
		return map;
	}

}
