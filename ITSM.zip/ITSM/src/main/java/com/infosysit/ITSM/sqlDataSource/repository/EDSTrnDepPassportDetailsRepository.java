package com.infosysit.ITSM.sqlDataSource.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosysit.ITSM.model.EDSTrnDepPassportDetailsModel;
import com.infosysit.ITSM.sqlDataSource.entity.EDSTrnDepPassportDetails;
import com.infosysit.ITSM.util.QueryConstants;

public interface EDSTrnDepPassportDetailsRepository extends JpaRepository<EDSTrnDepPassportDetails, Integer> {
	
	@Query(value=QueryConstants.GETDEPENDENTPASSPORTDETAILS)
	List<EDSTrnDepPassportDetailsModel> GetDependentPassportDetails(@Param("txtEmpNo") String txtEmpNo);
	

}
