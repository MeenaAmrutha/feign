package com.infosysit.ITSM.util;

public class InfraConstants {
	 // <summary>
    /// Domain prefix
    /// </summary>
    public static String INFOSYSDOMAINPREFIXITL = "ITLINFOSYS\\";

    /// <summary>
    /// Domain prefix
    /// </summary>
    public static String INFOSYSDOMAINSUFFIX = "@INFOSYS.COM";

    /// <summary>
    /// Domain prefix
    /// </summary>
    public static String INFOSYSDOMAINSUFFIXAD = "@AD.INFOSYS.COM";
}
