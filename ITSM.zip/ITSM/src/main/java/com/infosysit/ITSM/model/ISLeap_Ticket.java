package com.infosysit.ITSM.model;

import java.util.Date;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ISLeap_Ticket {
	public String caller;
	public String number;
	public String shortdescription;
	public String category;
	public Date createdDate;
	public String sysId;
	public Integer madesla;
	public ISLeap_Ticket( String caller,String number,String shortdescription,String category,Date createdDate,String sysId, Integer madesla) {
		super();
		this.caller=caller;
		this.number=number;
		this.shortdescription=shortdescription;
		this.category=category;
		this.createdDate=createdDate;
		this.sysId=sysId;
		this.madesla=madesla;
	}
}
