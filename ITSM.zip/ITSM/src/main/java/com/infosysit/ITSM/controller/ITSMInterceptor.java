package com.infosysit.ITSM.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.sunbird.telemetry.util.TelemetryLmaxWriter;

import com.infosysit.ITSM.telemetry.LogEvent;
@Component
//Intercepting every request here and sending Log event data to telemetry service
//This class handles Log event data
@SuppressWarnings("unused")
public class ITSMInterceptor extends LogEvent implements HandlerInterceptor {
private String message;

	
	
	private TelemetryLmaxWriter lmaxWriter = TelemetryLmaxWriter.getInstance();

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
		// Intialize Telemetry
		
		super.initializeRequestInfo();

		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView view)
			throws Exception {
		// do nothing
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception exception) {

		// Send Telemetry events

		super.setEventData(message, request, response);

	}
}
