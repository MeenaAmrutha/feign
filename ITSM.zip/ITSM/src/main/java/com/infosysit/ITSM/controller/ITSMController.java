package com.infosysit.ITSM.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosysit.ITSM.telemetry.AuditEvent;

import com.infosysit.ITSM.util.Message;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.infosysit.ITSM.service.ITSMServiceImpl;


@RestController
@RequestMapping("/api/v1/ITSM")
public class ITSMController {
	@Autowired
	private ITSMServiceImpl service;
	
	@Autowired
	private AuditEvent audit;
	
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "100000") })
 	@PostMapping(path = "/DecisionAnalysis", produces = "application/json")
	 public ResponseEntity<Object> DecisionAnalysis() throws Exception {
 		
		try {
			//log.log("/DecisionAnalysis");
			service.decisionAnalysis();
			return  ResponseEntity.ok(true);	
			
		} catch (Exception e) {
		e.printStackTrace();
			audit.setEventData(e.getStackTrace().toString());
			return ResponseEntity.ok(Message.SOMEERROROCCURED);
		}
 		
 	}
	
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "100000") })
 	@PostMapping(path = "/AutoResponse", produces = "application/json")
	 public ResponseEntity<Object> AutoResponse() throws Exception{
 		
		try {
			//log.log("/DecisionAnalysis");
			service.autoResponse();
			return  ResponseEntity.ok(true);	
			
		} catch (Exception e) {
			e.printStackTrace();
			audit.setEventData(e.getStackTrace().toString());
			return ResponseEntity.ok( Message.SOMEERROROCCURED);
		}
 		
 	}
	
	public ResponseEntity<Object> defaultFallback() {
        return ResponseEntity.ok( "Timeout! FallBack of Method");
    }
		
}
