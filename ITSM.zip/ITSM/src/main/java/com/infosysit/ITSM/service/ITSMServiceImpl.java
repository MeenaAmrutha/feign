package com.infosysit.ITSM.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosysit.ITSM.model.EDSTrnDepPassportDetailsModel;
import com.infosysit.ITSM.model.ISLeap_AutoResponseModel;
import com.infosysit.ITSM.model.ISLeap_Ticket;
import com.infosysit.ITSM.mysqlDataSource.repository.ICM_TicketsRepository;
import com.infosysit.ITSM.mysqlDataSource.repository.ISLeapMstAutoResponseRepository;
import com.infosysit.ITSM.mysqlDataSource.repository.ISLeapTrnRuleMappingRepository;
import com.infosysit.ITSM.sqlDataSource.repository.EDSTrnDepPassportDetailsRepository;


@Service
public class ITSMServiceImpl implements ITSMService {
	
	@Autowired
	private ICM_TicketsRepository icm_TicketsRepository;
	
	@Autowired
    private	ISLeapMstAutoResponseRepository isLeapAutoResponseRepository;
	
	@Autowired
	private ISLeapTrnRuleMappingRepository isLeapRuleMappingRepository;
	
	@Autowired
	private EDSTrnDepPassportDetailsRepository edsTrnDepPassportDetailsRepository;
	
	@Override
	public void decisionAnalysis() throws Exception
    {
		List<EDSTrnDepPassportDetailsModel> lstDependentPassportDetails1=edsTrnDepPassportDetailsRepository.GetDependentPassportDetails("1002413");
		System.out.println(lstDependentPassportDetails1.get(0).getTxtEmpNo());
		List<ISLeap_Ticket> lstIcmTickets=icm_TicketsRepository.GetIcmOpenTickets();
		
		if(lstIcmTickets.size()>0)
		{
			for(ISLeap_Ticket icmTicket:lstIcmTickets)
			{
				String txtEmpNo=icmTicket.getCaller();
				String ticketNumber=icmTicket.getNumber();
				List<EDSTrnDepPassportDetailsModel> lstDependentPassportDetails=edsTrnDepPassportDetailsRepository.GetDependentPassportDetails(txtEmpNo);
				String dependentNames="";
				String resolutionSteps="";
				if(lstDependentPassportDetails.size()>0) {
					for(EDSTrnDepPassportDetailsModel record:lstDependentPassportDetails) {
						dependentNames+=record.getTxtNameInPassPort()+",";
					}
					dependentNames=dependentNames.substring(0,dependentNames.length()-1)+".";
					resolutionSteps="The details of below dependents are present in Harmony. If details of any dependent is not present, kindly add in Harmony and then raise new travel request. If travel request is already submitted, please recall and raise new travel request. Name of Dependents in harmony are :"+ dependentNames;
				}
				else 
				{
					resolutionSteps="There are no dependent details present in harmony.kindly add dependent details in Harmony and then raise new travel request.";
				}
				icm_TicketsRepository.UpdateIcmTicketsUsingNumber(ticketNumber,resolutionSteps);
				System.out.println("Done");
			}
		}
	}
	
	@Override
	public void autoResponse() throws Exception
    {
		
	    List<String> lstTicketNumbers=icm_TicketsRepository.GetIcmOpenTicketNumbers();
	    if(lstTicketNumbers.size()>0)
	    {
	    	for(String ticketNo : lstTicketNumbers) {
	    		int ruleNo=isLeapRuleMappingRepository.GetRuleUsingTickerNumber(ticketNo);
	    		ISLeap_AutoResponseModel resolutionSolution=isLeapAutoResponseRepository.GetResolutionDetails(ruleNo);
	    		if(resolutionSolution!=null)
	    		{
	    			
	    			String subcategory= resolutionSolution.getStatus().trim() +","+resolutionSolution.getNewCategoryName().trim()+","+resolutionSolution.getDeptName().trim();
	    			if(resolutionSolution.getTransfer().equalsIgnoreCase("Not Required"))
	    				icm_TicketsRepository.UpdateIcmTicketsNotRequired(ticketNo,resolutionSolution.getSuggestion().trim(),subcategory);
	    			else if(resolutionSolution.getTransfer().equalsIgnoreCase("Required"))
	    				icm_TicketsRepository.UpdateIcmTicketsNotRequired(ticketNo,resolutionSolution.getSuggestion().trim(),subcategory);
	    					
	    		}
	    	}
	    }
	    System.out.println("Done");
	}
	
		
	
}
