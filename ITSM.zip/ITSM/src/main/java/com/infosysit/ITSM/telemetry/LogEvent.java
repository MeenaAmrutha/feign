package com.infosysit.ITSM.telemetry;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.sunbird.common.models.util.JsonKey;
import org.sunbird.common.request.Request;
import org.sunbird.telemetry.util.TelemetryEvents;
import org.sunbird.telemetry.util.TelemetryLmaxWriter;

import com.infosysit.ITSM.telemetry.Event;

@SuppressWarnings("unchecked")
public class LogEvent extends Event{

	private TelemetryLmaxWriter lmaxWriter = TelemetryLmaxWriter.getInstance();
	
	public void setTelemetryData( String message, HttpServletRequest request, HttpServletResponse response) {

		super.initializeRequestInfo();
		setEventData(message,request,response);

	}
	
	
	public void setEventData (String message, HttpServletRequest request, HttpServletResponse response) {

		Map<String, Object> telemetryInfo = requestInfo.get(messageId);

		Request telemetryRequest = new Request();

		String methodName = request.getMethod();

		String url = request.getRequestURI();

		Map<String, Object> telemetryParameters = new HashMap<>();
		telemetryParameters.put(JsonKey.LOG_TYPE, super.logType);
// 		telemetryParameters.put(JsonKey.MESSAGE, "Telemetry for CollaborationAPI Service");
		telemetryParameters.put(JsonKey.METHOD, request.getMethod());
		telemetryParameters.put(JsonKey.STATUS, String.valueOf(response.getStatus()));
		telemetryParameters.put(JsonKey.URL, url);
		telemetryParameters.put(JsonKey.METHOD, methodName);

		if (response.getStatus() == 200 || response.getStatus() == 201)
			message = "Request returned Success";
		else if (response.getStatus() == 204)
			message = "No Content";
		else
			message = "Request returned Failure";

		telemetryParameters.put(JsonKey.MESSAGE, message);
		telemetryParameters.put(JsonKey.LOG_LEVEL, JsonKey.INFO);

		telemetryRequest.setRequest(generateTelemetryRequest(TelemetryEvents.LOG.getName(), telemetryParameters,
				(Map<String, Object>) telemetryInfo.get(JsonKey.CONTEXT)));

		lmaxWriter.submitMessage(telemetryRequest);
	}
	
	
	private Map<String, Object> generateTelemetryRequest(String eventType, Map<String, Object> telemetryParameters,
			Map<String, Object> telemetryContext) {
		Map<String, Object> map = new HashMap<>();
		map.put(JsonKey.TELEMETRY_EVENT_TYPE, eventType);
		map.put(JsonKey.CONTEXT, telemetryContext);
		map.put(JsonKey.PARAMS, telemetryParameters);

		return map;
	}
	
}
