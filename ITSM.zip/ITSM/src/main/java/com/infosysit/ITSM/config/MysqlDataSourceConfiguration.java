package com.infosysit.ITSM.config;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableJpaRepositories(
        entityManagerFactoryRef = "mysqlEntityManager",
        		transactionManagerRef = "mysqlTransactionManager",
        basePackages = "com.infosysit.ITSM.mysqlDataSource.repository"
)
public class MysqlDataSourceConfiguration {
	@Bean
    @Primary
    @ConfigurationProperties(prefix = "spring.mysqldatasource")
    public DataSource mysqlDataSource() {
        return DataSourceBuilder
                    .create()
                    .build();
    }
 
    @Primary
    @Bean(name = "mysqlEntityManager")
    public LocalContainerEntityManagerFactoryBean mysqlEntityManagerFactory(EntityManagerFactoryBuilder builder) {
        return builder.dataSource(mysqlDataSource())
                    .packages("com.infosysit.ITSM.mysqlDataSource.entity") // you can also give the package where the Entities are given rather than giving Entity class
            		.persistenceUnit("mysqldatasource")
                    .build();
    }
    
    @Bean(name = "mysqlTransactionManager")
    public PlatformTransactionManager mysqlTransactionManager(@Qualifier("mysqlEntityManager") EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }
}
