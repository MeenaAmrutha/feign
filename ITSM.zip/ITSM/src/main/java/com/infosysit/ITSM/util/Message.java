package com.infosysit.ITSM.util;

import org.springframework.beans.factory.annotation.Value;

public class Message {
	@Value("${schema.sql}")
	public static String schema;
	
	public static final String SuccessMySqlDB="SuccessFully Connected to MYSQL";
	public static final String SuccessSqlDB="SuccessFully Connected to SQL";
	public static final String Inserted="SuccessFully Inserted";

	public static final String Selected="SuccessFully Selected Data";

	public static final String StartedJob="Started Job";
	
	public static final String EndJob="Ended Job";
	
	public static final String NoDataFound="No Data Found";
	
	public static final String Unauthorized="Authorization is required";
	
	public static final String InvalidToken="Invalid token";
	
	public static final String SOMEERROROCCURED="Some Error Occured";
	
	//public static final String SchemaSQl=schema;
	
}
