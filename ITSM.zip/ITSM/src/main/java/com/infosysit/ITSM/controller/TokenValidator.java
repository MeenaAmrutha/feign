package com.infosysit.ITSM.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.codec.binary.Base64;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.handler.MappedInterceptor;


import com.infosysit.ITSM.util.Message;

@Component
@EnableAutoConfiguration
public class TokenValidator {
	
	public static String jsonUPN=null;
	public static String jsonEmpNo=null;
	public static String jwtToken=null;
	@Component
    public static class AccessToken {
   
		public boolean judgeToken(HttpServletRequest request) throws Exception{
        	String token = request.getHeader("Authorization");
            if(token!=null) {
            	
    			try {
    				jwtToken=token;
    				String jwt = token.substring(7, token.length());
                	String[] split_string = jwt.split("\\.");
        			String base64EncodedBody = split_string[1];
        			Base64 base64Url = new Base64(true);
        			String body = new String(base64Url.decode(base64EncodedBody));
        			JSONObject json = new JSONObject(body);
        			jsonEmpNo=json.get("EmpNo").toString();
        			jsonUPN=json.getString("upn");
    			}
    			catch(Exception e) {
    				throw new Exception(Message.InvalidToken);
    			}

            	 return true;
            }else {
            	throw new Exception(Message.Unauthorized);
            	
            }           
        }

    }
	
	
	  @Bean	  
	  @Autowired 
	  public MappedInterceptor getMappedInterceptor(TokenInterceptor tokenInterceptor) { 
		  return new MappedInterceptor(new String[] { "/api/v1/**" },new String[] { "/api/v1/ITSM/**" }, tokenInterceptor);
	  }
	 
	 
	
	@Component
    public static class TokenInterceptor implements HandlerInterceptor {

        @Autowired
        AccessToken accessToken;

        @Override
        public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
            return accessToken.judgeToken(request);
        }
    }

}
