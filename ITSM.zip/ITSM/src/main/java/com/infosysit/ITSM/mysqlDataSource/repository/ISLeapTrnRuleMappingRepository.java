package com.infosysit.ITSM.mysqlDataSource.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosysit.ITSM.mysqlDataSource.entity.ISLeapTrnRuleMapping;
import com.infosysit.ITSM.util.QueryConstants;

public interface ISLeapTrnRuleMappingRepository extends JpaRepository<ISLeapTrnRuleMapping, Integer> {
	
	@Query(value=QueryConstants.GETRULEUSINGTICKETNUMBER)
	int GetRuleUsingTickerNumber(@Param("txtAhdTicket") String txtAhdTicket);
	

}
