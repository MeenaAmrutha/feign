package com.infosysit.ITSM.service;


public interface ITSMService {
	public void decisionAnalysis() throws Exception;
    public void autoResponse() throws Exception;
}
