package com.infosysit.ITSM.mysqlDataSource.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name="ISLeapTrnRuleMapping" )
@NoArgsConstructor
public class ISLeapTrnRuleMapping {
	@Id
	@Column(name="txtAhdTicket")
	private String txtAhdTicket;
	
	@Column(name="intRuleNo")
	private int intRuleNo;

}
