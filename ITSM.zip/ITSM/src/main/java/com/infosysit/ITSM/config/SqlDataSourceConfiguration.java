package com.infosysit.ITSM.config;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;



@Configuration
@EnableJpaRepositories(
        entityManagerFactoryRef = "sqlEntityManager",
        		transactionManagerRef = "sqlTransactionManager",
        basePackages = "com.infosysit.ITSM.sqlDataSource.repository")
public class SqlDataSourceConfiguration {
	@Value("${schema.sql}")
	private String schemaSql;
	
	@Bean
    @ConfigurationProperties(prefix = "springsecond.sqldatasource")
    public DataSource sqlDataSource() {
        return DataSourceBuilder
                    .create()
                    .build();
    }
 
   
   /* @Bean(name = "sqlEntityManager")
    public LocalContainerEntityManagerFactoryBean secondsqlEntityManagerFactory(EntityManagerFactoryBuilder builder) {
        return builder.dataSource(sqlDataSource())
                    .packages("com.infosysit.ITSM.sqlDataSource.entity") // you can also give the package where the Entities are given rather than giving Entity class
            		.persistenceUnit("sqldatasource")
                    .build();
    }*/
	
    @Bean(name = "sqlEntityManager")
    public LocalContainerEntityManagerFactoryBean secondsqlEntityManagerFactory(
            EntityManagerFactoryBuilder builder) {
    	
        Map<String, Object> properties = new HashMap<String, Object>();
        //properties.put("hibernate.hbm2ddl.auto", "update");
        properties.put("hibernate.default_schema", schemaSql);
        return builder
                .dataSource(sqlDataSource())
                .packages("com.infosysit.ITSM.sqlDataSource.entity")
                .persistenceUnit("sqldatasource")
                .properties(properties)
                .build();
    }
    
    @Bean(name = "sqlTransactionManager")
    public PlatformTransactionManager secondsqlTransactionManager(@Qualifier("sqlEntityManager") EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }
}
